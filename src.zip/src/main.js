import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { CivicProvider } from './context/CivicContext';
import { AuthProvider } from './context/AuthContext';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <CivicProvider>
          <App />
        </CivicProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
);
